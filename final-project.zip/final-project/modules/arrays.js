module.exports =
{
    grassArr: [],
    grassEaterArr: [],
    predatorArr: [],
    bombArr: [],
    fireArr: [],
    chargeArr: [],
    player: false
}